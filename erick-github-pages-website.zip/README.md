# Erick Omondi Aketch — GitHub Pages Website

A responsive personal academic/professional website built with plain HTML, CSS and JavaScript.

## Files

- `index.html` — main website
- `css/style.css` — styling and responsive design
- `js/script.js` — mobile navigation and dynamic year
- `cv.pdf` — add your CV here

## Publish on GitHub Pages

1. Create a GitHub repository named `YOURUSERNAME.github.io`.
2. Upload `index.html`, the `css` folder, the `js` folder and your `cv.pdf`.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Visit `https://YOURUSERNAME.github.io`.

## Personalize

Before publishing, replace:
- `your-email@example.com` with your real email.
- The LinkedIn `#` with your LinkedIn profile.
- Project `#` links with your actual repositories/pages.
- Add your CV as `cv.pdf`.
- Replace the `EA` avatar with a photo later if desired.
